<?php
// Check if the AJAX request has been sent
if (isset($_POST['action']) && $_POST['action'] == 'start') {
    // Call the PHP function
    $postID = $_POST['postID'];
    participate($postID);
}

if (isset($_POST['action']) && $_POST['action'] == 'stop') {
    // Call the PHP function
    $postID = $_POST['postID'];
    stop_participating($postID);
}

if (isset($_POST['action']) && $_POST['action'] == 'delete') {
    // Call the PHP function
    $postID = $_POST['postID'];
    delete_post($postID);
}
// PHP function to be called via AJAX
function participate($pID) 
{
    session_start();
    require_once("database.php");
    $con = db_con("db_posts");
    $uID = $_SESSION['id'];
    $query1 = "SELECT COUNT(*) FROM project_participation WHERE userID =" . $uID . " AND projectID=" . $pID .";";
    $result1 = mysqli_query($con, $query1);
    $result1 =  implode(mysqli_fetch_assoc($result1));
    if ($result1 == '0') {
        $query2 = "INSERT INTO project_participation (userID, projectID) Values(" . $uID . ", " . $pID . ");";
        $result2 = mysqli_query($con, $query2);
        echo "success";
    } else {
        echo "not successful";
    }

}

function stop_participating($pID) 
{
    session_start();
    require_once("database.php");
    $con = db_con("db_posts");
    $uID = $_SESSION['id'];
    $query = "DELETE FROM project_participation WHERE userID=" . $uID . " AND projectID=$pID;";
    $result = mysqli_query($con, $query);

}

function delete_post($pID) 
{
    session_start();
    require_once("database.php");
    $con = db_con("db_posts");
    $query1 = "DELETE FROM project_participation WHERE projectID=$pID;";
    $result1 = mysqli_query($con, $query1);
    $query2 = "DELETE FROM tb_posts WHERE AUTHOR='" . $_SESSION["username"] . "' AND ID=$pID;";
    $result2 = mysqli_query($con, $query2);

}
?>