<!DOCTYPE html> 
<html> 
<head> 
 <title style="margin: 0;">Helping Hands</title> 
 <meta charset="UTF-8"> 
 <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
 <link rel="stylesheet" type="text/css" href="style_Profile.css"> 
</head> 
<body > 
 <header style="margin: 0px; padding: 0px; border: 0px;"> 
        <div style="background-color: #bfd1d0;"> 
  <h1 style="height: 75px;">Helping Hands</h1> 
        </div> 
 </header> 
 <navbar>
			<ul>
				<li><a href="index.html">Home</a></li>
				<li><a href="profile.php">Profile</a></li>
				<li><a href="projects.php">Projects</a></li>
				<li><a href="support.php">Support</a></li>
				<?php
        if (!isset($_SESSION)) {
          header('location:loginpage.php');
        }
				if (isset($_SESSION['name'])) {
					echo "<li>Hello, ";
					echo $_SESSION['name'];
					echo "!";
					echo "<a href='logout.php' title='logout'>LOGOUT</a></li>";
				} else {
					echo "<li><a href='loginpage.php'>Log In</a></li>";
				}
				?>

			</ul>
		</navbar>
   <body> 
  <header> 
   <title>Profile</title> 
  </header> 
<main> 
<div style="padding-top: 1px;">
        <div style="margin: 25px; background-color: #D1D0BF; right: 0; position: absolute;">
          <button id="EditProfile"> Edit Profile </button>
          
          </div>
      </div>
    
  <script>
    const EditProfile = document.getElementById("EditProfile");

    EditProfile.addEventListener("click", function() 
    { 
      const EditWindow = window.open("./EditProfile.html", "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=500,left=500,width=2000px,height=700px");

    });

  </script>


  <section class="user-profile"> 
    <img src="https://static.tildacdn.com/tild3137-3361-4732-b939-646437633235/napassport_141.jpg" alt="Picture" width="150" height="200"> 
    <div class="user-info"> 
      <h2>Mary Garthner</h2> 
      <p class="title">Age: 27</p> 
      <p class="title">Location: Vienna, Austria</p> 
      <p class="title">Occupation: Teacher</p> 
      <!-- Another information about user --> 
    </div> 
  </section> 

</main> 
 
<footer> 
  <p>&copy; 2023 Company. All rights reserved.</p> 
</footer> 
 
   
 </body> 
 </html>
     

