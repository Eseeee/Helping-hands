<!DOCTYPE html>
<html>
<head>

        <title style="margin: 0;">Helping Hands</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="style_login.css">
		<?php
		?>
		<?php
			session_start();
			
			if(count($_POST)>0){
				require_once("database.php");
				$con = db_con('userlogin');
				$uname = $_POST['username'];
				$pw = $_POST['password'];
				$sql = "SELECT * FROM login_table WHERE UNAME='$uname' and PW = '$pw'";
				$result = mysqli_query($con, $sql);

				if(mysqli_num_rows($result) === 1) {
					echo("login ok");
					$row = mysqli_fetch_assoc($result);
					if($row['UNAME'] == $uname && $row['PW'] == $pw){
						
						echo("success");
						$_SESSION['id'] = $row['ID'];
						$_SESSION['name'] = $row['NAME']; 
						$_SESSION['username'] = $row['UNAME']; 
						header("location:projects.php"); 
					} }
				else { 
					echo "Invalid username or password";;	
			}
		}
			?>
</head>
<body>
		<header style="margin: 0px; padding: 0px; border: 0px;">
        <div style="background-color: #bfd1d0;">
		<h1 style="height: 75px;">Helping Hands</h1>
        </div>

		<navbar>
		<ul>
			<li><a href="index.php">Home</a></li>
		 	<li><a href="profile.php">Profile</a></li>
		 	<li><a href="projects.php">Projects</a></li>
		 	<li><a href="support.php">Support</a></li>
			
		</ul>
	  </navbar>
	  </header>
    <main style="height: 100%; margin: 0; padding: 0; background-color: gray;">
	<h1 style="padding-top: 10%;">
		<?php
			if(!empty($_SESSION['registered_successfully'])) {
				echo "Success! Time to Log in";
				unset($_SESSION['registered_successfully']);
			} else {
				echo "Log In";
			}
		?>
	</h1>
	<form style="background-color: #D1D0BF;" method="POST">
        
		<label for="username">Username</label>
		<input type="text" id="username" name="username" placeholder="Enter your username">
		
		<label for="password">Password</label>
		<input type="password" id="password" name="password" placeholder="Enter your password">
		
		<input type="submit" value="log in">
		<input value="register" type="button" onclick="location.href='register.php';" />
	</form>
</main>
</body>
</html>