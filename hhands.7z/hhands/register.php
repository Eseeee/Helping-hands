<!DOCTYPE html>
<html>
<head>

        <title style="margin: 0;">Helping Hands</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="style_login.css">
		<?php
			$con = mysqli_connect("localhost","root","");

			if (!$con) 
			{
				echo 'Connection to the server failed.';
			}
			
			if(!mysqli_select_db($con,'userlogin')) 
			{
				 echo 'Database cannot be accessed.';
			}
			
		?>
		<?php
			function validatePW($str) {
                // define regular expression pattern to check for at least one uppercase letter, one lowercase letter, one number, and one special character
                $pattern = '/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\w\s]).+$/';
                
                // use preg_match function to check if string matches the pattern
                if (preg_match($pattern, $str)) {
                  return true;
                } else {
                  return false;
                }
              }
              function check_user($uname) {
                //import global variable $con
                global $con;

                $sql = "SELECT * from login_table WHERE UNAME='$uname'";
                $result = mysqli_query($con, $sql);
                $row = mysqli_fetch_assoc($result);

                if (mysqli_num_rows($result) === 0) {
                    return false;
                } else {
                    return true;
                }
              }
              
              function validate_name($str) {
                // Check if the string contains only letters and space
                if (!preg_match('/^[a-zA-Z\s]+$/', $str)) {
                  return false;
                }
              
                // Split the string into two substrings using space as the delimiter
                $substrings = explode(' ', $str);
              
                // Check if there are exactly two substrings
                if (count($substrings) !== 2) {
                  return false;
                }
              
                // Check if each substring contains only letters
                foreach ($substrings as $substring) {
                  if (!ctype_alpha($substring)) {
                    return false;
                  }
                }
              
                // If all checks pass, return true
                return true;
              
              
            }
              function reg_user($form) {
                //imports global variable $con
                global $con;
                
                if (!validate_name($form['name'])) {
                    echo "name must consist of first and last name, separated by space.";
                    return;
                }
                $name = $form['name'];
                
                if (check_user($form['uname'])) {
                    echo "username taken";
                    return;
                }
                $uname = $form['uname'];

                //run pw validation function
                if (!validatePW($form['pw'])) {
                    echo "password does not fit criteria";
                    return;
                }

                $pw = $form['pw'];
                
                $sql = "INSERT INTO login_table (NAME, UNAME, PW) Values ('$name', '$uname', '$pw');";
                $result = mysqli_query($con, $sql);
            
                if ($result === TRUE) {
                    $_SESSION['registered_successfully'] = 'TRUE';
                    header("Location: loginpage.php");
                }
                }
              session_start();
			if(count($_POST)>0){
                reg_user($_POST);
		    }
			?>
</head>
<body>
    <header style="margin: 0px; padding: 0px; border: 0px;">
        <div style="background-color: #bfd1d0;">
		<h1 style="height: 75px;">Helping Hands</h1>
        </div>
	</header>
    <main style="height: 100%; margin: 0; padding: 0; background-color: gray;">
	<h1 style="padding-top: 10%;">Login</h1>
	<form style="background-color: #D1D0BF;" method="POST">
        
        <label for="username">Name</label>
		<input type="text" id="name" name="name" placeholder="Enter your name">

		<label for="username">Username</label>
		<input type="text" id="username" name="uname" placeholder="Enter your username">
		
		<label for="password">Password</label>
		<input type="password" id="password" name="pw" placeholder="Enter your password">
		
		
		<input value="log in" type="button" onclick="location.href='loginpage.php';" />
        <input type="submit" value="register">
	</form>
</main>
</body>
</html>