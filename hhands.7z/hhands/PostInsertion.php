<?php 

$con = mysqli_connect("localhost","root","");

if (!$con) 
{
    echo 'Connection to the server failed.';
}

if(!mysqli_select_db($con,'db_posts')) 
{
     echo 'Database cannot be accessed.';
}


$Title = $_POST['PostTitle'];
$Content = $_POST['PostContent'];
session_start();
$Author = $_SESSION['username'];

$sql= "INSERT INTO tb_posts(PostTitle, PostContent, AUTHOR) VALUES('$Title', '$Content', '$Author')";

if(!mysqli_query($con,$sql)){echo 'Insertion failed';}else{echo 'Inserted into DB.';}

header("refresh:2; url=HelpingHands_Forums.php");

echo "<script>window.close();</script>";


?>