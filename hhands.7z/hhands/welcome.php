<!DOCTYPE html>
<html>
    <head>
        <title>welcome!</title>
    </head>
    <body>
        <?php
        session_start();
        ?>
        <p>
            Welcome, <?php echo $_SESSION['name']; ?> ! 
        </p>
        

    </body>

</html>