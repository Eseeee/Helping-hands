<?php session_start(); ?>
<!DOCTYPE html>
<html>

<head>
	<title style="margin: 0;">Helping Hands</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style_forums.css">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body style="background-color: gray;">
	<header style="margin: 0px; padding: 0px; border: 0px;">
		<div style="background-color: #bfd1d0;">
			<h1 style="height: 75px;">Helping Hands</h1>
		</div>

		<navbar>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="profile.php">Profile</a></li>
				<li><a href="projects.php">Projects</a></li>
				<li><a href="support.php">Support</a></li>
				<?php
				if (!isset($_SESSION)) {
					header('location:loginpage.php');
				  }
				if (isset($_SESSION['name'])) {
					echo "<li>Hello, ";
					echo $_SESSION['name'];
					echo "!";
					echo "<a href='logout.php' title='logout'>LOGOUT</a></li>";
				} else {
					echo "<li><a href='loginpage.php'>Log In</a></li>";
				}
				?>

			</ul>
		</navbar>
	</header>
	<main style="height: 100%; margin: 0; padding: 0; background-color: gray;">
		<div style="padding-top: 1px;">
			<div style="margin: 25px; background-color: #D1D0BF; right: 0; position: absolute;">
				<button id="CreatePostBT"> Create Project </button>

			</div>
		</div>

		<script>
			const CreatePostBT = document.getElementById("CreatePostBT");

			CreatePostBT.addEventListener("click", function () {
				const NewPost = window.open("./newpost.html", "_blank", "toolbar=,scrollbars=yes,resizable=yes,top=50,left=500,width=750px,height=1000px");

			});

		</script>
		<script>
			$(document).ready(function () {
				// Attach click event handler to the button

				$('.participate').on('click', function () {
					var id = $(this).attr('id');
					// Make an AJAX call to the PHP function
					$.ajax({
						url: 'participate.php', // Change to your PHP file's path
						type: 'POST',
						data: { action: 'start', postID: id }, // Pass any data as needed
						success: function (response) {
							// Handle the response from PHP function
							location.reload();
						},
						error: function (xhr, status, error) {
							// Handle errors
							console.error(error);
						}
					});
				});
				$('.stop_participating').on('click', function () {
					var id = $(this).attr('id');
					// Make an AJAX call to the PHP function
					$.ajax({
						url: 'participate.php', // Change to your PHP file's path
						type: 'POST',
						data: { action: 'stop', postID: id }, // Pass any data as needed
						success: function (response) {
							// Handle the response from PHP function
							location.reload();

						},
						error: function (xhr, status, error) {
							// Handle errors
							console.error(error);
						}
					});
				});

				$('.delete').on('click', function () {
					var id = $(this).attr('id');
					// Make an AJAX call to the PHP function

					$.ajax({
						url: 'participate.php', // Change to your PHP file's path
						type: 'POST',
						data: { action: 'delete', postID: id }, // Pass any data as needed
						success: function (response) {
							// Handle the response from PHP function
							$('#result').html(response);
							location.reload();
						},
						error: function (xhr, status, error) {
							// Handle errors
							console.error(error);
						}
					});
				});
				$('.postlink').on('click', function () {
					var title = $.attr('id');
					
				});
			});
		</script>

		<div style="border: 5px solid black;margin: 120px 50px  50px 50px; padding-bottom: 500px;">
			<h1 style="padding: 30px;">Projects:</h1>

			<div id="ptable">

				<?php
				function loadtable()
				{
					require_once("database.php");
					$con = db_con("db_posts");
					$query1 = "SELECT * FROM tb_posts";
					$result1 = mysqli_query($con, $query1);

					if (mysqli_num_rows($result1) > 0) {

						// output data of each row
						echo "<table align='center' border='1px' style='width:70vw;'>";
						echo "<tr><th>Author</th><th>Post Tile</th><th>Post Content</th><th>No. of participants</th><th>Participate</th><th>Delete</th></tr>";

						while ($row = mysqli_fetch_assoc($result1)) {
							echo "<tr>";
							echo "<td>" . $row["AUTHOR"] . "</td>";
							echo "<td class='postlink' id='" . $row['PostTitle'] . "'>" . $row["PostTitle"] . "</td>";
							echo "<td>" . $row["PostContent"] . "</td>";

							$query2 = "SELECT * FROM project_participation WHERE projectID=" . $row["ID"];
							$result2 = mysqli_query($con, $query2);
							echo "<td>";
							echo mysqli_num_rows($result2);

							echo "</td>";
							echo "<td>";
							$query3 = "SELECT COUNT(*) FROM project_participation WHERE userID =" . $_SESSION['id'] . " AND projectID=" . $row['ID'] . ";";
							$result3 = mysqli_query($con, $query3);
							$result3 = implode(mysqli_fetch_assoc($result3));
							if ($result3 > 0) {
								echo "<button class='stop_participating' id='" . $row["ID"] . "'> stop participating </button>";
							} else {
								echo "<button class='participate' id='" . $row["ID"] . "'> Participate </button>";
							}
							echo "</td>";
							echo "<td>";
							if ($row["AUTHOR"] == $_SESSION["username"]) {
								echo "<button class='delete' id='" . $row["ID"] . "' style='background-color:red'> Delete </button>";
							} else {
								echo "<button class='_delete' id='" . $row["ID"] . "' style='background-color:grey'> Delete </button>";
							}
							echo "</td>";
							echo "</tr>";


						}
						echo "</table>";

					}
				}
				loadtable();
				?>
			</div>
			<div id="result">
			</div>

		</div>



	</main>




</body>