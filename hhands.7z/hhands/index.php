<!DOCTYPE html>
<html>
<head>
	<title style="margin: 0;">Helping Hands</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="style_forums.css">
</head>
<body>
    <header style="margin: 0px; padding: 0px; border: 0px;">
			<div style="background-color: #bfd1d0;">
			<h1 style="height: 75px;">Helping Hands</h1>
			</div>
			<navbar>
				<ul>
					<li><a href="index.html">Home</a></li>
					<li><a href="profile.php">Profile</a></li>
					<li><a href="projects.php">Projects</a></li>
					<li><a href="support.php">Support</a></li>
					<?php
					if (isset($_SESSION['name'])) {
						echo "<li>Hello, ";
						echo $_SESSION['name'];
						echo "!";
						echo "<a href='logout.php' title='logout'>LOGOUT</a></li>";
					} else {
						echo "<li><a href='loginpage.php'>Log In</a></li>";
					}
					?>
	
				</ul>
			</navbar>
	</header>
	<main style="margin: 0px; padding: 2px; border: 0px; 
	background-image: url('https://virginiahelpinghands.com/resources/Pictures/Helping%20folder%20adobe%20pics/AdobeStock_296202515.jpeg'); 
	background-size: cover; 
	background-repeat: no-repeat;">
	<div id='bw_white' style="background-color: rgba(255, 255, 255, 0.7); width: 60%; margin: 0 auto;">
		<section id="banner" >
			<h2 style="color: rgb(220, 239, 245); text-shadow: 0 0 10px black, 0 0 5px black;">There are always people in need. But we CAN make a difference!!!</h2>
			<p>Our service aims to bring volunteer and people in need together. Sign up today to ask for help or help those in need!</p>
			
            <span style="color: rgb(220, 239, 245);margin: 15px; padding: 15px;"><button href="loginpage.php" class="btn"><b>Sign in</b></button></span> 
            <span style="margin: 15px;"><button href="#volunteer" class="btn"><b>Register</b></button></span>
		</section>
		<section id="about">
			<h2 style="color: rgb(220, 239, 245); text-shadow: 0 0 10px black, 0 0 5px black;">About Us</h2>
			<p>Helping Hands was founded in 2010 with the goal of providing assistance to those who need it most. We believe that everyone deserves a helping hand, and we work tirelessly to ensure that our services are accessible to all.</p>
			<p>Our team is made up of dedicated volunteers who share our vision of making the world a better place. We are committed to helping those in need and creating a more just and equitable society.</p>
		</section>
				</div id='bw_white'>
		<section id="services" style="padding: 300px; padding-top: 0">
			<h2 style="color: rgb(220, 239, 245); text-shadow: 0 0 10px black, 0 0 5px black;">Our Services</h2>
			<div class="container">
				<div class="carousel">
				  <div class="carousel__face"><span>Animal Welfare</span></div>
				  <div class="carousel__face"><span>Senior Support</span></div>
				  <div class="carousel__face"><span>Tutoring & Mentoring</span></div>
				  <div class="carousel__face"><span>Neighborhood Watch</span></div>
				  <div class="carousel__face"><span>Community Events</span></div>
				  <div class="carousel__face"><span>Park & Trail Maintenance</span></div>
				  <div class="carousel__face"><span>Food Distribution</span></div>
				  <div class="carousel__face"><span>Homeless Outreach</span></div>
				  <div class="carousel__face"><span>Clothing Donations</span></div>
				</div>
			  </div>
		</section>
    </main>
</body>