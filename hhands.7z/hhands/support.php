<!DOCTYPE html> 
<html> 
<head> 
 <title style="margin: 0;">Helping Hands</title> 
 <meta charset="UTF-8"> 
 <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
 <link rel="stylesheet" type="text/css" href="style_Profile.css"> 
</head> 
<body > 
 <header style="margin: 0px; padding: 0px; border: 0px;"> 
        <div style="background-color: #bfd1d0;"> 
  <h1 style="height: 75px;">Helping Hands</h1> 
        </div> 
 </header> 
 <navbar>
			<ul>
				<li><a href="index.php">Home</a></li>
				<li><a href="profile.php">Profile</a></li>
				<li><a href="projects.php">Projects</a></li>
				<li><a href="">Support</a></li>
				<?php
				if (isset($_SESSION['name'])) {
					echo "<li>Hello, ";
					echo $_SESSION['name'];
					echo "!";
					echo "<a href='logout.php' title='logout'>LOGOUT</a></li>";
				} else {
					echo "<li><a href='loginpage.php'>Log In</a></li>";
				}
				?>

			</ul>
		</navbar>
   <body> 
  <header> 
   <title>Support</title> 
  </header> 
<main>
    

<section id="contact">
    <h2>Contact Us</h2>
    <form>
        <label for="name">Name:</label>
        <input type="text" id="name" name="name">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email">
        <label for="message">Message:</label>
        <textarea id="message" name></textarea>
    </form>
</section>

</main> 
 
<footer> 
  <p>&copy; 2023 Company. All rights reserved.</p> 
</footer> 
 
   
 </body> 
 </html>
     


