<?php
	function db_con($database) {
		
			$con = mysqli_connect("localhost","root","");

			if (!$con) 
			{
				echo 'Connection to the server failed.';
			}
			
			if(!mysqli_select_db($con,$database)) 
			{
				 echo 'Database cannot be accessed.';
			}
			return $con;
			
	}
		?>